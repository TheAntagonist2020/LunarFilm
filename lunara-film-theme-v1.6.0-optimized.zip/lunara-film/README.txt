Lunara Film Child Theme (Patch Package)

This ZIP contains the Lunara Film child theme files with an upgraded "Lunara Debrief" signature treatment
and additional Customizer controls for header spacing and logo sizing.

If you're already using this child theme on lunarafilm.com, you can safely copy/overwrite:
- style.css
- functions.php
and keep your existing theme folder name/structure.

After updating, if any permalinks behave oddly, go to:
Settings → Permalinks → Save Changes (no changes required).

