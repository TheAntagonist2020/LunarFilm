# Lunara Film Theme v1.6.0

**A sophisticated WordPress child theme for prestige film criticism.**

Built for [lunarafilm.com](https://lunarafilm.com) — Beyond the Frame.

---

## 📦 What's Included

### Core Files
- `style.css` — Complete dark blue (#0a1520) and gold (#c9a961) styling
- `functions.php` — All shortcodes, Reviews post type, helper functions
- `header.php` — Simplified 4-item navigation (HOME | REVIEWS | SEARCH | ABOUT)
- `footer.php` — Minimal footer with tagline
- `single-reviews.php` — Individual review template with Dispatch Debrief
- `archive-reviews.php` — Reviews listing grid

### Features
- ✅ Reviews custom post type with full metadata
- ✅ Star rating display (supports "4", "4.5", "★★★★☆" formats)
- ✅ Content badge system (Review, News, Essay, Dispatch)
- ✅ Dispatch Debrief module (Where to Watch, Pair It With)
- ✅ Flexible homepage shortcodes
- ✅ Magazine-style content grid
- ✅ Mobile responsive
- ✅ Google Fonts (Playfair Display, Source Serif Pro)

---

## 🚀 Installation

### Requirements
- WordPress 6.0+
- Blocksy theme (parent theme) installed and active
- PHP 7.4+

### Steps

1. **Install Blocksy parent theme** (if not already installed)
   - Appearance → Themes → Add New → Search "Blocksy" → Install & Activate

2. **Upload this child theme**
   - Appearance → Themes → Add New → Upload Theme
   - Select `lunara-film-theme-v1.6.0.zip`
   - Click "Install Now"

3. **Activate the child theme**
   - Click "Activate" after installation

4. **Flush permalinks**
   - Go to Settings → Permalinks
   - Click "Save Changes" (even without changing anything)
   - This ensures the Reviews post type works correctly

5. **Upload your logo** (optional)
   - Appearance → Customize → Site Identity → Logo

---

## 📝 Shortcode Reference

### [lunara_home] — Complete Homepage

Displays: Featured hero + Oscars promo + Mixed content grid

```
[lunara_home]
```

**Options:**
```
[lunara_home hero="true" count="9" show_oscar="true"]
```
- `hero` — Show featured review hero (true/false)
- `count` — Number of items in feed (default: 9)
- `show_oscar` — Show Academy Awards promo block (true/false)

---

### [lunara_feed] — Mixed Content Grid

Displays reviews and posts in a chronological grid.

```
[lunara_feed]
```

**Options:**
```
[lunara_feed count="9" title="Latest" mixed="true"]
```
- `count` — Number of items (default: 9)
- `title` — Section heading (default: "Latest")
- `mixed` — Include posts AND reviews (true/false, default: true)
- `type` — Specific post type: "reviews" or "post"
- `category` — Filter by category slug

**Examples:**
```
[lunara_feed count="6" title="Recent Reviews" type="reviews"]
[lunara_feed count="4" title="News" category="news"]
```

---

### [lunara_featured] — Featured Review Hero

Large hero display for one featured review.

```
[lunara_featured]
```

Automatically pulls reviews with `featured` or `feature_on_homepage` meta set to "1", or defaults to most recent review.

---

### [lunara_reviews] — Reviews Only Grid

```
[lunara_reviews count="6" title="Latest Reviews"]
```

---

### [lunara_news] — News Posts Grid

```
[lunara_news count="6" title="Latest News" category="news"]
```

---

### [lunara_oscars] — Academy Awards Promo

```
[lunara_oscars]
```

**Options:**
```
[lunara_oscars title="Academy Awards Database" subtitle="Explore our comprehensive archive." cta_text="Explore" cta_url="/academy-awards/"]
```

---

## 🏠 Homepage Setup

### Quick Start

1. Go to **Pages → All Pages → Home** (or create new page)
2. Delete existing content
3. Paste this:

```
[lunara_home]
```

4. Click **Update**
5. Done!

### Custom Homepage

For more control:

```
[lunara_featured]

[lunara_oscars]

[lunara_feed count="6" title="Latest Reviews" type="reviews"]

[lunara_feed count="4" title="Latest News" category="news"]
```

---

## ✍️ Creating Reviews

### Add a New Review

1. **Reviews → Add New**

2. **Fill in the content:**
   - Title: Film name (e.g., "Anora")
   - Content: Your review text (800+ words recommended)
   - Featured Image: Movie poster or still

3. **Custom Fields** (add via Screen Options → Custom Fields):
   - `director` — Director name
   - `screenwriter` — Writer(s)
   - `cinematographer` — DP name
   - `composer` — Composer name
   - `lead_actor` — Main star(s)
   - `runtime` — Minutes (e.g., "139")
   - `genre` — Genre (e.g., "Drama")
   - `release_year` — Year (e.g., "2024")
   - `distributor` — Distributor name
   - `star_rating` — Rating (e.g., "4.5" or "★★★★½")
   
   **Dispatch Debrief fields:**
   - `where_to_watch` — Theatrical/streaming info
   - `theme_echo` — Theme Echo pairing (film + reason)
   - `counter_program` — Counter-Program pairing
   - `craft_mirror` — Craft Mirror pairing (optional)
   
   **Homepage feature:**
   - `featured` — Set to "1" to feature on homepage

4. **Publish**

---

## 🎨 Color Palette

| Name | Hex | Usage |
|------|-----|-------|
| Primary Background | `#0a1520` | Main page background |
| Secondary Background | `#0f1d2e` | Header gradient, sections |
| Card Background | `#1a2938` | Content cards |
| Primary Gold | `#c9a961` | Headings, links, accents |
| Gold Hover | `#e0c481` | Hover states |
| Text | `#e8e8e8` | Body text |
| Muted Text | `#a0a0a0` | Secondary text |

---

## 🔧 Customization

### Change Navigation Menu

1. **Appearance → Menus**
2. Create new menu, name it "Primary Menu"
3. Add your pages/links
4. Under "Menu Settings", check "Primary Menu"
5. Save

### Customize Colors

Edit CSS variables in `style.css`:

```css
:root {
    --lunara-bg-primary: #0a1520;
    --lunara-gold: #c9a961;
    /* etc. */
}
```

### Add Custom Logo

1. **Appearance → Customize → Site Identity**
2. Upload your logo image
3. Publish

---

## 📁 File Structure

```
lunara-film-theme-v1.6.0/
├── style.css              # All styling + theme header
├── functions.php          # Post types, shortcodes, helpers
├── header.php             # Site header + navigation
├── footer.php             # Site footer
├── single-reviews.php     # Single review template
├── archive-reviews.php    # Reviews listing page
└── README.txt             # This file
```

---

## ⚡ Troubleshooting

### Reviews page shows 404
→ Go to Settings → Permalinks → Save Changes

### Shortcode shows as text
→ Make sure theme is activated (not just installed)

### Styles not loading
→ Clear browser cache (Ctrl+Shift+R)
→ Check Blocksy parent theme is installed

### Star ratings not showing
→ Add `star_rating` custom field to your review
→ Values: "1" through "5", or "4.5", or "★★★★☆"

---

## 📞 Support

Theme created for Lunara Film.

**Version:** 1.6.0  
**Requires:** WordPress 6.0+, Blocksy Theme  
**License:** GPL v2 or later
