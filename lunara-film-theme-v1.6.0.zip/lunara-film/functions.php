<?php
/**
 * Lunara Film Theme Functions
 * 
 * @package Lunara_Film
 * @version 1.6.0
 * 
 * Features:
 * - Reviews custom post type with full metadata
 * - [lunara_home] homepage shortcode (featured hero + mixed feed)
 * - [lunara_feed] flexible content grid shortcode
 * - [lunara_featured] featured review hero shortcode
 * - [lunara_oscars] Academy Awards promo block
 * - Star rating helper functions
 * - Content badge system (Review, News, Essay, Dispatch)
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ==========================================================================
   1. THEME SETUP
   ========================================================================== */

add_action('after_setup_theme', function() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    // Custom image sizes
    add_image_size('lunara-hero', 1600, 900, true);
    add_image_size('lunara-card', 560, 360, true);
    add_image_size('lunara-poster', 300, 450, true);
    
    // Register navigation menu
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'lunara-film'),
    ));
});

/* ==========================================================================
   2. ENQUEUE STYLES
   ========================================================================== */

add_action('wp_enqueue_scripts', function() {
    // Google Fonts
    wp_enqueue_style(
        'lunara-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Source+Serif+Pro:wght@400;600&display=swap',
        array(),
        null
    );
    
    // Parent theme (Blocksy)
    wp_enqueue_style('blocksy-style', get_template_directory_uri() . '/style.css');
    
    // Child theme
    wp_enqueue_style(
        'lunara-film-style',
        get_stylesheet_uri(),
        array('blocksy-style'),
        '1.6.0'
    );
});

/* ==========================================================================
   3. REVIEWS CUSTOM POST TYPE
   ========================================================================== */

add_action('init', function() {
    register_post_type('reviews', array(
        'labels' => array(
            'name'               => 'Reviews',
            'singular_name'      => 'Review',
            'menu_name'          => 'Reviews',
            'add_new'            => 'Add New',
            'add_new_item'       => 'Add New Review',
            'edit_item'          => 'Edit Review',
            'new_item'           => 'New Review',
            'view_item'          => 'View Review',
            'search_items'       => 'Search Reviews',
            'not_found'          => 'No reviews found',
            'not_found_in_trash' => 'No reviews found in trash',
        ),
        'public'              => true,
        'has_archive'         => true,
        'rewrite'             => array('slug' => 'reviews'),
        'menu_icon'           => 'dashicons-video-alt3',
        'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest'        => true,
        'menu_position'       => 5,
        'publicly_queryable'  => true,
    ));
});

/* ==========================================================================
   4. HELPER FUNCTIONS
   ========================================================================== */

/**
 * Render star rating as HTML
 * Accepts formats: "4", "4.5", "★★★★", "★★★★☆"
 */
function lunara_render_stars($rating) {
    if (empty($rating)) {
        return '';
    }
    
    // If already contains star characters, return as-is
    if (strpos($rating, '★') !== false || strpos($rating, '☆') !== false) {
        return esc_html($rating);
    }
    
    // Convert numeric to stars
    $numeric = floatval($rating);
    $full_stars = floor($numeric);
    $half_star = ($numeric - $full_stars) >= 0.5;
    $empty_stars = 5 - $full_stars - ($half_star ? 1 : 0);
    
    $output = str_repeat('★', $full_stars);
    if ($half_star) {
        $output .= '½';
    }
    $output .= str_repeat('☆', $empty_stars);
    
    return $output;
}

/**
 * Get content badge HTML based on post type/category
 */
function lunara_get_content_badge($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $post_type = get_post_type($post_id);
    
    // Reviews
    if ($post_type === 'reviews') {
        return '<span class="lunara-badge lunara-badge--review">Review</span>';
    }
    
    // Regular posts - check categories
    if ($post_type === 'post') {
        $categories = get_the_category($post_id);
        if (!empty($categories)) {
            $cat_slug = $categories[0]->slug;
            $cat_name = $categories[0]->name;
            
            switch ($cat_slug) {
                case 'news':
                case 'dispatch':
                    return '<span class="lunara-badge lunara-badge--news">' . esc_html($cat_name) . '</span>';
                case 'essay':
                case 'essays':
                    return '<span class="lunara-badge lunara-badge--essay">Essay</span>';
                default:
                    return '<span class="lunara-badge lunara-badge--dispatch">' . esc_html($cat_name) . '</span>';
            }
        }
    }
    
    return '<span class="lunara-badge">Article</span>';
}

/**
 * Get excerpt with custom length
 */
function lunara_get_excerpt($post_id = null, $length = 25) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $excerpt = get_the_excerpt($post_id);
    if (empty($excerpt)) {
        $excerpt = get_the_content(null, false, $post_id);
    }
    
    $excerpt = wp_strip_all_tags($excerpt);
    $words = explode(' ', $excerpt);
    
    if (count($words) > $length) {
        $excerpt = implode(' ', array_slice($words, 0, $length)) . '…';
    }
    
    return $excerpt;
}

/* ==========================================================================
   5. [lunara_home] SHORTCODE - HOMEPAGE DISPLAY
   ========================================================================== */

function lunara_home_shortcode($atts) {
    $atts = shortcode_atts(array(
        'hero'       => 'true',
        'count'      => 9,
        'show_oscar' => 'true',
    ), $atts, 'lunara_home');
    
    ob_start();
    
    // Featured Hero Section
    if ($atts['hero'] === 'true') {
        echo lunara_featured_shortcode(array('style' => 'hero'));
    }
    
    // Oscars Promo (optional)
    if ($atts['show_oscar'] === 'true') {
        echo lunara_oscars_shortcode(array());
    }
    
    // Mixed Content Feed
    echo lunara_feed_shortcode(array(
        'count'   => $atts['count'],
        'title'   => 'Latest',
        'mixed'   => 'true',
    ));
    
    return ob_get_clean();
}
add_shortcode('lunara_home', 'lunara_home_shortcode');

/* ==========================================================================
   6. [lunara_featured] SHORTCODE - FEATURED REVIEW HERO
   ========================================================================== */

function lunara_featured_shortcode($atts) {
    $atts = shortcode_atts(array(
        'style' => 'hero', // 'hero' or 'card'
    ), $atts, 'lunara_featured');
    
    // Get featured review (meta_key = 'featured' or most recent)
    $args = array(
        'post_type'      => 'reviews',
        'posts_per_page' => 1,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'post_status'    => 'publish',
        'meta_query'     => array(
            'relation' => 'OR',
            array(
                'key'     => 'featured',
                'value'   => '1',
                'compare' => '=',
            ),
            array(
                'key'     => 'feature_on_homepage',
                'value'   => '1',
                'compare' => '=',
            ),
        ),
    );
    
    $query = new WP_Query($args);
    
    // Fallback to most recent review if no featured
    if (!$query->have_posts()) {
        $args = array(
            'post_type'      => 'reviews',
            'posts_per_page' => 1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'post_status'    => 'publish',
        );
        $query = new WP_Query($args);
    }
    
    if (!$query->have_posts()) {
        wp_reset_postdata();
        return '<div class="lunara-no-content">No featured review available.</div>';
    }
    
    ob_start();
    
    while ($query->have_posts()) {
        $query->the_post();
        
        $post_id = get_the_ID();
        $thumbnail = get_the_post_thumbnail_url($post_id, 'lunara-hero');
        $star_rating = get_post_meta($post_id, 'star_rating', true);
        $director = get_post_meta($post_id, 'director', true);
        $year = get_post_meta($post_id, 'release_year', true);
        $excerpt = lunara_get_excerpt($post_id, 35);
        
        // Build meta line
        $meta_parts = array();
        if ($director) $meta_parts[] = 'Directed by ' . esc_html($director);
        if ($year) $meta_parts[] = esc_html($year);
        $meta_line = implode(' • ', $meta_parts);
        ?>
        
        <section class="lunara-featured-hero" style="background-image: url('<?php echo esc_url($thumbnail); ?>');">
            <div class="lunara-featured-content">
                <span class="lunara-featured-badge">Featured Review</span>
                
                <h2 class="lunara-featured-title">
                    <a href="<?php echo esc_url(get_permalink()); ?>">
                        <?php the_title(); ?>
                    </a>
                </h2>
                
                <?php if ($meta_line) : ?>
                    <div class="lunara-featured-meta"><?php echo $meta_line; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($star_rating)) : ?>
                    <div class="lunara-featured-rating">
                        <span class="lunara-featured-stars">
                            <?php echo lunara_render_stars($star_rating); ?>
                        </span>
                        <span class="lunara-featured-rating-text">
                            <?php echo esc_html($star_rating); ?>/5
                        </span>
                    </div>
                <?php endif; ?>
                
                <div class="lunara-featured-excerpt">
                    <p><?php echo esc_html($excerpt); ?></p>
                </div>
                
                <a href="<?php echo esc_url(get_permalink()); ?>" class="lunara-button">
                    Read Review
                </a>
            </div>
        </section>
        
        <?php
    }
    
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('lunara_featured', 'lunara_featured_shortcode');

/* ==========================================================================
   7. [lunara_feed] SHORTCODE - MIXED CONTENT GRID
   ========================================================================== */

function lunara_feed_shortcode($atts) {
    $atts = shortcode_atts(array(
        'count'    => 9,
        'title'    => 'Latest',
        'mixed'    => 'true',      // true = reviews + posts, false = reviews only
        'type'     => '',          // specific post type: 'reviews', 'post'
        'category' => '',          // filter by category slug
        'columns'  => 3,
    ), $atts, 'lunara_feed');
    
    $count = intval($atts['count']);
    
    // Build query args
    if ($atts['mixed'] === 'true' && empty($atts['type'])) {
        // Mixed: Reviews + Posts
        $args = array(
            'post_type'      => array('reviews', 'post'),
            'posts_per_page' => $count,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'post_status'    => 'publish',
        );
    } else {
        // Single type
        $post_type = !empty($atts['type']) ? $atts['type'] : 'reviews';
        $args = array(
            'post_type'      => $post_type,
            'posts_per_page' => $count,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'post_status'    => 'publish',
        );
    }
    
    // Category filter
    if (!empty($atts['category'])) {
        $args['category_name'] = sanitize_text_field($atts['category']);
    }
    
    $query = new WP_Query($args);
    
    if (!$query->have_posts()) {
        wp_reset_postdata();
        return '<div class="lunara-no-content">No content available yet. Check back soon!</div>';
    }
    
    ob_start();
    ?>
    
    <section class="lunara-feed-section">
        <div class="lunara-feed-header">
            <h2 class="lunara-feed-title"><?php echo esc_html($atts['title']); ?></h2>
            <a href="<?php echo esc_url(get_post_type_archive_link('reviews')); ?>" class="lunara-feed-link">
                View All →
            </a>
        </div>
        
        <div class="lunara-feed-grid">
            <?php
            while ($query->have_posts()) {
                $query->the_post();
                
                $post_id = get_the_ID();
                $post_type = get_post_type($post_id);
                $thumbnail = get_the_post_thumbnail_url($post_id, 'lunara-card');
                $excerpt = lunara_get_excerpt($post_id, 20);
                
                // Get review-specific meta
                $star_rating = '';
                $director = '';
                $year = '';
                
                if ($post_type === 'reviews') {
                    $star_rating = get_post_meta($post_id, 'star_rating', true);
                    $director = get_post_meta($post_id, 'director', true);
                    $year = get_post_meta($post_id, 'release_year', true);
                }
                
                // Build meta line
                $meta_parts = array();
                if ($director) $meta_parts[] = esc_html($director);
                if ($year) $meta_parts[] = esc_html($year);
                if (empty($meta_parts)) {
                    $meta_parts[] = get_the_date('F j, Y');
                }
                $meta_line = implode(' • ', $meta_parts);
                ?>
                
                <article class="lunara-card">
                    <div class="lunara-card-image">
                        <?php echo lunara_get_content_badge($post_id); ?>
                        <?php if ($thumbnail) : ?>
                            <a href="<?php echo esc_url(get_permalink()); ?>">
                                <img src="<?php echo esc_url($thumbnail); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="lunara-card-body">
                        <h3 class="lunara-card-title">
                            <a href="<?php echo esc_url(get_permalink()); ?>">
                                <?php the_title(); ?>
                            </a>
                        </h3>
                        
                        <div class="lunara-card-meta"><?php echo $meta_line; ?></div>
                        
                        <?php if (!empty($star_rating)) : ?>
                            <div class="lunara-card-stars">
                                <?php echo lunara_render_stars($star_rating); ?>
                            </div>
                        <?php endif; ?>
                        
                        <p class="lunara-card-excerpt"><?php echo esc_html($excerpt); ?></p>
                        
                        <div class="lunara-card-footer">
                            <a href="<?php echo esc_url(get_permalink()); ?>" class="lunara-card-link">
                                Read More →
                            </a>
                        </div>
                    </div>
                </article>
                
                <?php
            }
            ?>
        </div>
    </section>
    
    <?php
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('lunara_feed', 'lunara_feed_shortcode');

/* ==========================================================================
   8. [lunara_oscars] SHORTCODE - ACADEMY AWARDS PROMO
   ========================================================================== */

function lunara_oscars_shortcode($atts) {
    $atts = shortcode_atts(array(
        'title'    => 'Academy Awards Database',
        'subtitle' => 'Explore our comprehensive Oscar nomination and winner archive. Search by year, category, film, or nominee.',
        'cta_text' => 'Explore the Database',
        'cta_url'  => '/academy-awards/',
    ), $atts, 'lunara_oscars');
    
    ob_start();
    ?>
    
    <div class="lunara-oscars-promo">
        <h3 class="lunara-oscars-title"><?php echo esc_html($atts['title']); ?></h3>
        <p class="lunara-oscars-subtitle"><?php echo esc_html($atts['subtitle']); ?></p>
        <a href="<?php echo esc_url($atts['cta_url']); ?>" class="lunara-oscars-cta">
            <?php echo esc_html($atts['cta_text']); ?>
        </a>
    </div>
    
    <?php
    return ob_get_clean();
}
add_shortcode('lunara_oscars', 'lunara_oscars_shortcode');

/* ==========================================================================
   9. [lunara_reviews] SHORTCODE - REVIEWS ONLY GRID
   ========================================================================== */

function lunara_reviews_shortcode($atts) {
    $atts = shortcode_atts(array(
        'count' => 6,
        'title' => 'Latest Reviews',
    ), $atts, 'lunara_reviews');
    
    return lunara_feed_shortcode(array(
        'count' => $atts['count'],
        'title' => $atts['title'],
        'mixed' => 'false',
        'type'  => 'reviews',
    ));
}
add_shortcode('lunara_reviews', 'lunara_reviews_shortcode');

/* ==========================================================================
   10. [lunara_news] SHORTCODE - NEWS/POSTS GRID
   ========================================================================== */

function lunara_news_shortcode($atts) {
    $atts = shortcode_atts(array(
        'count'    => 6,
        'title'    => 'Latest News',
        'category' => 'news',
    ), $atts, 'lunara_news');
    
    return lunara_feed_shortcode(array(
        'count'    => $atts['count'],
        'title'    => $atts['title'],
        'mixed'    => 'false',
        'type'     => 'post',
        'category' => $atts['category'],
    ));
}
add_shortcode('lunara_news', 'lunara_news_shortcode');

/* ==========================================================================
   11. FLUSH REWRITE RULES ON ACTIVATION
   ========================================================================== */

add_action('after_switch_theme', function() {
    flush_rewrite_rules();
});
