<?php
/**
 * Lunara Film Header Template
 * 
 * Simplified navigation: HOME | REVIEWS | SEARCH | ABOUT
 * 
 * @package Lunara_Film
 * @version 1.6.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="lunara-header">
    <div class="lunara-logo">
        <?php 
        $custom_logo_id = get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $logo_url = wp_get_attachment_image_url($custom_logo_id, 'full');
            echo '<a href="' . esc_url(home_url('/')) . '">';
            echo '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_bloginfo('name')) . '">';
            echo '</a>';
        }
        ?>
    </div>
    
    <h1 class="lunara-site-title">
        <a href="<?php echo esc_url(home_url('/')); ?>" style="color: inherit; text-decoration: none;">
            LUNARA FILM
        </a>
    </h1>
    
    <nav class="lunara-nav-menu" aria-label="Primary Navigation">
        <?php
        // Check for custom menu first
        if (has_nav_menu('primary')) {
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'items_wrap'     => '%3$s',
                'link_before'    => '',
                'link_after'     => '',
            ));
        } else {
            // Default navigation
            ?>
            <a href="<?php echo esc_url(home_url('/')); ?>">HOME</a>
            <a href="<?php echo esc_url(home_url('/reviews/')); ?>">REVIEWS</a>
            <a href="<?php echo esc_url(home_url('/?s=')); ?>">SEARCH</a>
            <a href="<?php echo esc_url(home_url('/about/')); ?>">ABOUT</a>
            <?php
        }
        ?>
    </nav>
</header>

<main id="main" class="site-main">
