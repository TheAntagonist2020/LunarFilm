<?php
/**
 * Lunara Film Footer Template
 * 
 * @package Lunara_Film
 * @version 1.6.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
</main>

<footer class="lunara-footer">
    <p class="lunara-footer-tagline">Beyond the Frame</p>
    <p class="lunara-footer-copy">
        &copy; <?php echo date('Y'); ?> Lunara Film. All rights reserved.
    </p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
