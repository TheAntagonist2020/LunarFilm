<?php
/**
 * Single Review Template
 * 
 * Displays individual film reviews with full metadata,
 * star ratings, and Dispatch Debrief module.
 * 
 * @package Lunara_Film
 * @version 1.6.0
 */

get_header();

if (have_posts()) :
    while (have_posts()) :
        the_post();
        
        $post_id = get_the_ID();
        
        // Get all review metadata
        $star_rating     = get_post_meta($post_id, 'star_rating', true);
        $director        = get_post_meta($post_id, 'director', true);
        $screenwriter    = get_post_meta($post_id, 'screenwriter', true);
        $cinematographer = get_post_meta($post_id, 'cinematographer', true);
        $composer        = get_post_meta($post_id, 'composer', true);
        $lead_actor      = get_post_meta($post_id, 'lead_actor', true);
        $runtime         = get_post_meta($post_id, 'runtime', true);
        $genre           = get_post_meta($post_id, 'genre', true);
        $release_year    = get_post_meta($post_id, 'release_year', true);
        $distributor     = get_post_meta($post_id, 'distributor', true);
        
        // Dispatch Debrief fields
        $where_to_watch  = get_post_meta($post_id, 'where_to_watch', true);
        $theme_echo      = get_post_meta($post_id, 'theme_echo', true);
        $counter_program = get_post_meta($post_id, 'counter_program', true);
        $craft_mirror    = get_post_meta($post_id, 'craft_mirror', true);
        
        // Featured image
        $poster_url = get_the_post_thumbnail_url($post_id, 'lunara-hero');
?>

<article class="lunara-review-single">
    
    <?php if ($poster_url) : ?>
        <div class="lunara-review-poster" style="text-align: center; margin-bottom: 40px;">
            <img src="<?php echo esc_url($poster_url); ?>" alt="<?php the_title_attribute(); ?>" style="max-width: 100%; height: auto; border-radius: 8px;">
        </div>
    <?php endif; ?>
    
    <header class="lunara-review-header">
        <h1 class="lunara-review-film-title">
            <?php the_title(); ?>
            <?php if ($release_year) : ?>
                <span class="lunara-review-film-year">(<?php echo esc_html($release_year); ?>)</span>
            <?php endif; ?>
        </h1>
    </header>
    
    <?php if ($star_rating) : ?>
        <div class="lunara-review-rating-block">
            <span class="lunara-review-stars-large">
                <?php echo lunara_render_stars($star_rating); ?>
            </span>
            <span class="lunara-review-score">
                <?php echo esc_html($star_rating); ?>/5
            </span>
        </div>
    <?php endif; ?>
    
    <?php
    // Build credits array
    $credits = array();
    if ($director)        $credits['Director'] = $director;
    if ($screenwriter)    $credits['Screenwriter'] = $screenwriter;
    if ($cinematographer) $credits['Cinematographer'] = $cinematographer;
    if ($composer)        $credits['Composer'] = $composer;
    if ($lead_actor)      $credits['Starring'] = $lead_actor;
    if ($runtime)         $credits['Runtime'] = $runtime . ' min';
    if ($genre)           $credits['Genre'] = $genre;
    if ($distributor)     $credits['Distributor'] = $distributor;
    
    if (!empty($credits)) :
    ?>
        <div class="lunara-review-credits">
            <?php foreach ($credits as $label => $value) : ?>
                <div class="lunara-credit-item">
                    <div class="lunara-credit-label"><?php echo esc_html($label); ?></div>
                    <div class="lunara-credit-value"><?php echo esc_html($value); ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <div class="lunara-review-content">
        <?php the_content(); ?>
    </div>
    
    <?php
    // Dispatch Debrief Module
    $has_debrief = $where_to_watch || $theme_echo || $counter_program || $craft_mirror;
    
    if ($has_debrief) :
    ?>
        <aside class="lunara-debrief">
            <h3 class="lunara-debrief-title">Dispatch Debrief</h3>
            
            <?php if ($star_rating) : ?>
                <div class="lunara-debrief-row">
                    <span class="lunara-debrief-label">Dispatch Score</span>
                    <span class="lunara-debrief-value">
                        <?php echo lunara_render_stars($star_rating); ?>
                    </span>
                </div>
            <?php endif; ?>
            
            <?php if ($where_to_watch) : ?>
                <div class="lunara-debrief-row">
                    <span class="lunara-debrief-label">Where to Watch</span>
                    <span class="lunara-debrief-value">
                        <?php echo esc_html($where_to_watch); ?>
                    </span>
                </div>
            <?php endif; ?>
            
            <?php if ($theme_echo || $counter_program || $craft_mirror) : ?>
                <div class="lunara-debrief-row">
                    <span class="lunara-debrief-label">Pair It With</span>
                    <div class="lunara-debrief-value">
                        <?php if ($theme_echo) : ?>
                            <div class="lunara-pairing">
                                <div class="lunara-pairing-type">Theme Echo</div>
                                <div class="lunara-pairing-film"><?php echo wp_kses_post($theme_echo); ?></div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($counter_program) : ?>
                            <div class="lunara-pairing">
                                <div class="lunara-pairing-type">Counter-Program</div>
                                <div class="lunara-pairing-film"><?php echo wp_kses_post($counter_program); ?></div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($craft_mirror) : ?>
                            <div class="lunara-pairing">
                                <div class="lunara-pairing-type">Craft Mirror</div>
                                <div class="lunara-pairing-film"><?php echo wp_kses_post($craft_mirror); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </aside>
    <?php endif; ?>
    
</article>

<?php
    endwhile;
endif;

get_footer();
