<?php
/**
 * Reviews Archive Template
 * 
 * Displays all reviews in a grid layout.
 * 
 * @package Lunara_Film
 * @version 1.6.0
 */

get_header();
?>

<div class="lunara-archive-header">
    <h1 class="lunara-archive-title">Reviews</h1>
    <p class="lunara-archive-description">
        Film criticism that goes beyond the frame. Thoughtful analysis, honest verdicts.
    </p>
</div>

<div class="lunara-archive-grid">
    <?php
    if (have_posts()) :
        while (have_posts()) :
            the_post();
            
            $post_id = get_the_ID();
            $thumbnail = get_the_post_thumbnail_url($post_id, 'lunara-card');
            $star_rating = get_post_meta($post_id, 'star_rating', true);
            $director = get_post_meta($post_id, 'director', true);
            $year = get_post_meta($post_id, 'release_year', true);
            $excerpt = lunara_get_excerpt($post_id, 20);
            
            // Build meta line
            $meta_parts = array();
            if ($director) $meta_parts[] = esc_html($director);
            if ($year) $meta_parts[] = esc_html($year);
            $meta_line = implode(' • ', $meta_parts);
    ?>
            
            <article class="lunara-card">
                <div class="lunara-card-image">
                    <?php echo lunara_get_content_badge($post_id); ?>
                    <?php if ($thumbnail) : ?>
                        <a href="<?php echo esc_url(get_permalink()); ?>">
                            <img src="<?php echo esc_url($thumbnail); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                        </a>
                    <?php endif; ?>
                </div>
                
                <div class="lunara-card-body">
                    <h3 class="lunara-card-title">
                        <a href="<?php echo esc_url(get_permalink()); ?>">
                            <?php the_title(); ?>
                        </a>
                    </h3>
                    
                    <?php if ($meta_line) : ?>
                        <div class="lunara-card-meta"><?php echo $meta_line; ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($star_rating)) : ?>
                        <div class="lunara-card-stars">
                            <?php echo lunara_render_stars($star_rating); ?>
                        </div>
                    <?php endif; ?>
                    
                    <p class="lunara-card-excerpt"><?php echo esc_html($excerpt); ?></p>
                    
                    <div class="lunara-card-footer">
                        <a href="<?php echo esc_url(get_permalink()); ?>" class="lunara-card-link">
                            Read Review →
                        </a>
                    </div>
                </div>
            </article>
            
    <?php
        endwhile;
        
        // Pagination
        the_posts_pagination(array(
            'mid_size'  => 2,
            'prev_text' => '← Previous',
            'next_text' => 'Next →',
        ));
        
    else :
    ?>
        <div class="lunara-no-content">
            No reviews published yet. Check back soon!
        </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
